import java.util.*;

// Binary Tree Node class
class TreeNode {
    int data;
    TreeNode left;
    TreeNode right;
    
    public TreeNode(int data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }
}

// Binary Tree implementation with traversal methods
class BinaryTree {
    TreeNode root;
    
    // Constructor to build tree from array
    public BinaryTree(int[] values) {
        if (values.length == 0) {
            root = null;
            return;
        }
        root = buildTree(values, 0);
    }
    
    // Recursive method to build a complete binary tree from array
    private TreeNode buildTree(int[] values, int index) {
        if (index >= values.length) {
            return null;
        }
        
        TreeNode node = new TreeNode(values[index]);
        node.left = buildTree(values, 2 * index + 1);
        node.right = buildTree(values, 2 * index + 2);
        
        return node;
    }
    
    // BFS Traversal (Breadth-First Search) using Queue
    public List<Integer> bfsTraversal() {
        List<Integer> result = new ArrayList<>();
        
        if (root == null) {
            return result;
        }
        
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        
        while (!queue.isEmpty()) {
            TreeNode current = queue.poll();
            result.add(current.data);
            
            if (current.left != null) {
                queue.offer(current.left);
            }
            
            if (current.right != null) {
                queue.offer(current.right);
            }
        }
        
        return result;
    }
    
    // BFS Level Order Traversal (showing levels)
    public Map<Integer, List<Integer>> bfsLevelOrder() {
        Map<Integer, List<Integer>> levelMap = new LinkedHashMap<>();
        
        if (root == null) {
            return levelMap;
        }
        
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        int level = 0;
        
        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            List<Integer> currentLevel = new ArrayList<>();
            
            for (int i = 0; i < levelSize; i++) {
                TreeNode current = queue.poll();
                currentLevel.add(current.data);
                
                if (current.left != null) {
                    queue.offer(current.left);
                }
                
                if (current.right != null) {
                    queue.offer(current.right);
                }
            }
            
            levelMap.put(level, currentLevel);
            level++;
        }
        
        return levelMap;
    }
    
    // DFS - Inorder Traversal (Left, Root, Right)
    public List<Integer> dfsInorder() {
        List<Integer> result = new ArrayList<>();
        dfsInorderHelper(root, result);
        return result;
    }
    
    private void dfsInorderHelper(TreeNode node, List<Integer> result) {
        if (node == null) {
            return;
        }
        dfsInorderHelper(node.left, result);
        result.add(node.data);
        dfsInorderHelper(node.right, result);
    }
    
    // DFS - Preorder Traversal (Root, Left, Right)
    public List<Integer> dfsPreorder() {
        List<Integer> result = new ArrayList<>();
        dfsPreorderHelper(root, result);
        return result;
    }
    
    private void dfsPreorderHelper(TreeNode node, List<Integer> result) {
        if (node == null) {
            return;
        }
        result.add(node.data);
        dfsPreorderHelper(node.left, result);
        dfsPreorderHelper(node.right, result);
    }
    
    // DFS - Postorder Traversal (Left, Right, Root)
    public List<Integer> dfsPostorder() {
        List<Integer> result = new ArrayList<>();
        dfsPostorderHelper(root, result);
        return result;
    }
    
    private void dfsPostorderHelper(TreeNode node, List<Integer> result) {
        if (node == null) {
            return;
        }
        dfsPostorderHelper(node.left, result);
        dfsPostorderHelper(node.right, result);
        result.add(node.data);
    }
    
    // DFS Iterative using Stack (Preorder)
    public List<Integer> dfsIterative() {
        List<Integer> result = new ArrayList<>();
        
        if (root == null) {
            return result;
        }
        
        Stack<TreeNode> stack = new Stack<>();
        stack.push(root);
        
        while (!stack.isEmpty()) {
            TreeNode current = stack.pop();
            result.add(current.data);
            
            // Push right first so left is processed first
            if (current.right != null) {
                stack.push(current.right);
            }
            
            if (current.left != null) {
                stack.push(current.left);
            }
        }
        
        return result;
    }
    
    // Display tree structure visually
    public void displayTree() {
        if (root == null) {
            System.out.println("Tree is empty.");
            return;
        }
        System.out.println("\nTree Structure:");
        displayTreeHelper(root, 0);
    }
    
    private void displayTreeHelper(TreeNode node, int level) {
        if (node == null) {
            return;
        }
        
        displayTreeHelper(node.right, level + 1);
        
        for (int i = 0; i < level; i++) {
            System.out.print("    ");
        }
        System.out.println(node.data);
        
        displayTreeHelper(node.left, level + 1);
    }
}

public class BinaryTreeTraversal {
    public static void main(String[] args) {
        // Predefined data in an array
        int[] predefinedData = {10, 5, 15, 3, 7, 12, 18, 1, 4, 6, 8, 11, 13, 16, 20};
        
        System.out.println("============================================");
        System.out.println("   BINARY TREE TRAVERSAL DEMONSTRATION");
        System.out.println("============================================");
        
        // Display the input array
        System.out.print("\nInput Array: [");
        for (int i = 0; i < predefinedData.length; i++) {
            System.out.print(predefinedData[i]);
            if (i < predefinedData.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
        
        // Create binary tree from the array
        BinaryTree tree = new BinaryTree(predefinedData);
        
        // Display tree structure
        tree.displayTree();
        
        System.out.println("\n============================================");
        System.out.println("     BREADTH-FIRST SEARCH (BFS) TRAVERSAL");
        System.out.println("============================================");
        
        // BFS Traversal
        List<Integer> bfsResult = tree.bfsTraversal();
        System.out.println("\nBFS Traversal (Level by Level):");
        System.out.println(formatTraversal(bfsResult));
        
        // BFS Level Order
        System.out.println("\nBFS Level Order Traversal:");
        Map<Integer, List<Integer>> levelOrder = tree.bfsLevelOrder();
        for (Map.Entry<Integer, List<Integer>> entry : levelOrder.entrySet()) {
            System.out.println("Level " + entry.getKey() + ": " + entry.getValue());
        }
        
        System.out.println("\n============================================");
        System.out.println("     DEPTH-FIRST SEARCH (DFS) TRAVERSAL");
        System.out.println("============================================");
        
        // DFS Inorder Traversal
        List<Integer> inorderResult = tree.dfsInorder();
        System.out.println("\nDFS Inorder Traversal (Left, Root, Right):");
        System.out.println(formatTraversal(inorderResult));
        
        // DFS Preorder Traversal
        List<Integer> preorderResult = tree.dfsPreorder();
        System.out.println("\nDFS Preorder Traversal (Root, Left, Right):");
        System.out.println(formatTraversal(preorderResult));
        
        // DFS Postorder Traversal
        List<Integer> postorderResult = tree.dfsPostorder();
        System.out.println("\nDFS Postorder Traversal (Left, Right, Root):");
        System.out.println(formatTraversal(postorderResult));
        
        // DFS Iterative
        List<Integer> dfsIterResult = tree.dfsIterative();
        System.out.println("\nDFS Iterative Traversal (using Stack):");
        System.out.println(formatTraversal(dfsIterResult));
        
        System.out.println("\n============================================");
        System.out.println("           TRAVERSAL SUMMARY");
        System.out.println("============================================");
        System.out.println("\nTraversal Methods Comparison:");
        System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        System.out.printf("%-15s : %s%n", "BFS (Queue)", formatTraversal(bfsResult));
        System.out.printf("%-15s : %s%n", "DFS Inorder", formatTraversal(inorderResult));
        System.out.printf("%-15s : %s%n", "DFS Preorder", formatTraversal(preorderResult));
        System.out.printf("%-15s : %s%n", "DFS Postorder", formatTraversal(postorderResult));
        System.out.printf("%-15s : %s%n", "DFS Iterative", formatTraversal(dfsIterResult));
        System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        
        System.out.println("\nApplications:");
        System.out.println("• BFS: Shortest path, level-order processing, nearest neighbor");
        System.out.println("• DFS Inorder: Get sorted order in BST, expression evaluation");
        System.out.println("• DFS Preorder: Copy tree, prefix expression, serialization");
        System.out.println("• DFS Postorder: Delete tree, postfix expression, space calculation");
    }
    
    // Helper method to format traversal result
    private static String formatTraversal(List<Integer> traversal) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < traversal.size(); i++) {
            sb.append(traversal.get(i));
            if (i < traversal.size() - 1) {
                sb.append(" → ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
}