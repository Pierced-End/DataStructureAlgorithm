import java.util.*;

class TreeNode {
    int data;
    TreeNode left, right;
    TreeNode(int data) { this.data = data; }
}

class BinaryTree {
    TreeNode root;
    
    BinaryTree(int[] values) {
        root = buildTree(values, 0);
    }
    
    private TreeNode buildTree(int[] values, int i) {
        if (i >= values.length) return null;
        TreeNode node = new TreeNode(values[i]);
        node.left = buildTree(values, 2 * i + 1);
        node.right = buildTree(values, 2 * i + 2);
        return node;
    }
    
    // BFS with level tracking
    void bfs() {
        if (root == null) return;
        
        System.out.println("\n--- BFS Traversal (Process) ---");
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        int level = 0;
        
        while (!queue.isEmpty()) {
            int size = queue.size();
            System.out.print("Level " + level + ": ");
            List<Integer> currentLevel = new ArrayList<>();
            
            for (int i = 0; i < size; i++) {
                TreeNode curr = queue.poll();
                currentLevel.add(curr.data);
                System.out.print(curr.data + " ");
                if (curr.left != null) queue.offer(curr.left);
                if (curr.right != null) queue.offer(curr.right);
            }
            System.out.println("→ Queue after: " + queueToString(queue));
            level++;
        }
    }
    
    private String queueToString(Queue<TreeNode> queue) {
        List<Integer> vals = new ArrayList<>();
        for (TreeNode n : queue) vals.add(n.data);
        return vals.toString();
    }
    
    // DFS Inorder with process tracking
    void dfsInorder() {
        System.out.println("\n--- DFS Inorder Traversal (Process) ---");
        System.out.print("Path: ");
        inorder(root);
        System.out.println();
    }
    
    private void inorder(TreeNode node) {
        if (node == null) {
            System.out.print("null ");
            return;
        }
        System.out.print("(L← ");
        inorder(node.left);
        System.out.print("[" + node.data + "] ");
        inorder(node.right);
        System.out.print("→R) ");
    }
    
    // DFS Preorder with process tracking
    void dfsPreorder() {
        System.out.println("\n--- DFS Preorder Traversal (Process) ---");
        System.out.print("Path: ");
        preorder(root);
        System.out.println();
    }
    
    private void preorder(TreeNode node) {
        if (node == null) {
            System.out.print("null ");
            return;
        }
        System.out.print("[" + node.data + "] ");
        preorder(node.left);
        preorder(node.right);
    }
    
    // DFS Postorder with process tracking
    void dfsPostorder() {
        System.out.println("\n--- DFS Postorder Traversal (Process) ---");
        System.out.print("Path: ");
        postorder(root);
        System.out.println();
    }
    
    private void postorder(TreeNode node) {
        if (node == null) {
            System.out.print("null ");
            return;
        }
        postorder(node.left);
        postorder(node.right);
        System.out.print("[" + node.data + "] ");
    }
    
    // DFS Iterative with stack tracking
    void dfsIterative() {
        if (root == null) return;
        
        System.out.println("\n--- DFS Iterative Traversal (Process) ---");
        Stack<TreeNode> stack = new Stack<>();
        stack.push(root);
        int step = 0;
        
        while (!stack.isEmpty()) {
            TreeNode curr = stack.pop();
            System.out.println("Step " + (++step) + ": Pop " + curr.data + " | Stack: " + stackToString(stack));
            if (curr.right != null) {
                stack.push(curr.right);
                System.out.println("       Push right " + curr.right.data + " | Stack: " + stackToString(stack));
            }
            if (curr.left != null) {
                stack.push(curr.left);
                System.out.println("       Push left " + curr.left.data + " | Stack: " + stackToString(stack));
            }
        }
    }
    
    private String stackToString(Stack<TreeNode> stack) {
        List<Integer> vals = new ArrayList<>();
        for (TreeNode n : stack) vals.add(n.data);
        return vals.toString();
    }
    
    // Clean results
    void printResults() {
        System.out.println("\n=== FINAL TRAVERSAL RESULTS ===");
        System.out.println("BFS:          " + getBFSResult());
        System.out.println("DFS Inorder:  " + getDFSInorderResult());
        System.out.println("DFS Preorder: " + getDFSPreorderResult());
        System.out.println("DFS Postorder:" + getDFSPostorderResult());
        System.out.println("DFS Iterative:" + getDFSIterativeResult());
    }
    
    private List<Integer> getBFSResult() {
        List<Integer> result = new ArrayList<>();
        if (root == null) return result;
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        while (!queue.isEmpty()) {
            TreeNode curr = queue.poll();
            result.add(curr.data);
            if (curr.left != null) queue.offer(curr.left);
            if (curr.right != null) queue.offer(curr.right);
        }
        return result;
    }
    
    private List<Integer> getDFSInorderResult() {
        List<Integer> result = new ArrayList<>();
        inorderCollect(root, result);
        return result;
    }
    
    private void inorderCollect(TreeNode node, List<Integer> result) {
        if (node == null) return;
        inorderCollect(node.left, result);
        result.add(node.data);
        inorderCollect(node.right, result);
    }
    
    private List<Integer> getDFSPreorderResult() {
        List<Integer> result = new ArrayList<>();
        preorderCollect(root, result);
        return result;
    }
    
    private void preorderCollect(TreeNode node, List<Integer> result) {
        if (node == null) return;
        result.add(node.data);
        preorderCollect(node.left, result);
        preorderCollect(node.right, result);
    }
    
    private List<Integer> getDFSPostorderResult() {
        List<Integer> result = new ArrayList<>();
        postorderCollect(root, result);
        return result;
    }
    
    private void postorderCollect(TreeNode node, List<Integer> result) {
        if (node == null) return;
        postorderCollect(node.left, result);
        postorderCollect(node.right, result);
        result.add(node.data);
    }
    
    private List<Integer> getDFSIterativeResult() {
        List<Integer> result = new ArrayList<>();
        if (root == null) return result;
        Stack<TreeNode> stack = new Stack<>();
        stack.push(root);
        while (!stack.isEmpty()) {
            TreeNode curr = stack.pop();
            result.add(curr.data);
            if (curr.right != null) stack.push(curr.right);
            if (curr.left != null) stack.push(curr.left);
        }
        return result;
    }
}

public class BinaryTreeTraversal {
    public static void main(String[] args) {
        int[] data = {10, 5, 15, 3, 7, 12, 18};
        BinaryTree tree = new BinaryTree(data);
        
        System.out.println("Binary Tree: [10, 5, 15, 3, 7, 12, 18]");
        System.out.println("Tree Structure:");
        System.out.println("        10");
        System.out.println("      /    \\");
        System.out.println("     5      15");
        System.out.println("    / \\    /  \\");
        System.out.println("   3   7  12   18");
        
        tree.bfs();
        tree.dfsPreorder();
        tree.dfsInorder();
        tree.dfsPostorder();
        tree.dfsIterative();
        tree.printResults();
    }
}